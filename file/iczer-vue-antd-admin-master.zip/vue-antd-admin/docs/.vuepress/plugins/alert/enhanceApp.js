import AlertMixin from './alertMixin'

export default ({Vue}) => {
  Vue.use(AlertMixin)
}