import account from './account'
import setting from './setting'

export default {account, setting}